﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;


namespace zadanie4
{
    public partial class Form1 : Form
    {
        Hashtable catalog = new Hashtable();
        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "Диск";
            dataGridView1.Columns[1].Name = "Исполнитель";
            dataGridView1.Columns[2].Name = "Песня";
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
        private void UpdateDataGridView()
        {
            dataGridView1.Rows.Clear();
            foreach (DictionaryEntry it in catalog)
            {
                string disk = it.Key.ToString();
                ArrayList songs = (ArrayList)it.Value;
                string[] row = { disk, songs[0].ToString(), songs[1].ToString() };
                dataGridView1.Rows.Add(row);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                if (textBox1.Text != "")
                {
                    if (textBox2.Text != "")
                    {
                        string disk = textBox3.Text;
                        if (!catalog.ContainsKey(disk))
                        {
                            catalog.Add(disk, new ArrayList());
                            string singer = textBox1.Text;
                            string song = textBox2.Text;
                            ArrayList songs = (ArrayList)catalog[disk];
                            songs.Add(singer);
                            songs.Add(song);
                            UpdateDataGridView();
                        }
                        else MessageBox.Show("Диск с таким наполнением уже существует!", "Ошибка", MessageBoxButtons.OK);
                    }
                    else MessageBox.Show("Вы не ввели название песни!", "Ошибка", MessageBoxButtons.OK);
                }
                else MessageBox.Show("Вы не ввели исполнителя!", "Ошибка", MessageBoxButtons.OK);
            }
            else MessageBox.Show("Вы не ввели название диска!", "Ошибка", MessageBoxButtons.OK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int delete = dataGridView1.SelectedCells[0].RowIndex;
            string disk = dataGridView1[0, delete].Value.ToString();
            catalog.Remove(disk);
            UpdateDataGridView();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            if (textBox4.Text != "")
            {
                listBox1.Visible = true;
                string artist = textBox4.Text;
                var querty = from DictionaryEntry it in catalog
                             where ((ArrayList)it.Value)[0].ToString() == artist
                             select new
                             { 
                                 Disk = it.Key,
                                 Singer = ((ArrayList)it.Value)[0],
                                 Song = ((ArrayList)it.Value)[1]
                             };
                listBox1.Items.Clear();
                foreach (var it in querty)
                {
                    string singer = (string)it.Singer, disk = (string)it.Disk, song = (string)it.Song;
                    string row = "Исполнитель " + singer.ToUpper() + " находится на диске " + disk.ToUpper() +  " с песней " + song.ToUpper();
                    listBox1.Items.Add(row);
                }
            }
            else MessageBox.Show("Вы не ввели исполнителя!", "Ошибка", MessageBoxButtons.OK);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("beatles.jpg");
            pictureBox2.Image = Image.FromFile("michael.jfif");
            pictureBox3.Image = Image.FromFile("queen.jfif");
        }
    }
}
